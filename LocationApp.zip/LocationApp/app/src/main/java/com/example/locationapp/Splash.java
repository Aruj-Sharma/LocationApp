package com.example.locationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

public class Splash extends AppCompatActivity {

    private String empty ="N/A";
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_splash);

        SharedPreferences sharedPreferences = getSharedPreferences("LocationSP", MODE_PRIVATE);

        String name = sharedPreferences.getString("name", "N/A");
        String phone = sharedPreferences.getString("phone","N/A");

        if(name.equals(empty) || phone.equals(empty))
        {
            Intent intent = new Intent(Splash.this, LoginActivity.class);

            handler.postDelayed(new Runnable() {
                public void run() {
                    startActivity(intent);
                }
            }, 2000);



        }

        else
        {
            Intent intent = new Intent(Splash.this, MainActivity.class);

            handler.postDelayed(new Runnable() {
                public void run() {
                    startActivity(intent);
                }
            }, 2000);

        }

    }
}